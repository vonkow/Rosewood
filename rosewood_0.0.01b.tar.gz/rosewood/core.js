var rw = {};


// Keydown Object
rw.keys = {};
// Global var Object
rw.g = {};
//Flags
rw.f = {};
//Runtime Functions
rw.r = {};
//Utility Functions 
rw.u = {};
//Param Functions - User-Defined
rw.p = {};
// Object Arrays
rw.items = [];
rw.pers = [];
rw.obst = [];
rw.ene = [];
rw.world = [];

